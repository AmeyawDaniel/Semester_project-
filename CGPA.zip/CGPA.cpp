#include <iostream>
#include <vector>

// Struct to represent a course
struct Course {
    std::string name;
    int credits;
    double grade;
};

// Function to calculate the GPA for a semester
double calculateGPA(const std::vector<Course>& courses) {
    int totalCredits = 0;
    double totalGradePoints = 0.0;

    for (const auto& course : courses) {
        totalCredits += course.credits;
        totalGradePoints += course.credits * course.grade;
    }

    return totalGradePoints / totalCredits;
}

// Function to calculate the CGPA based on the cumulative GPA and the number of semesters
double calculateCGPA(double cumulativeGPA, int numSemesters) {
    return cumulativeGPA / numSemesters;
}

int main() {
    int numCourses;
    std::cout << "Enter the number of courses: ";
    std::cin >> numCourses;

    std::vector<Course> courses;

    for (int i = 1; i <= numCourses; ++i) {
        std::cout << "Enter the name of course " << i << ": ";
        std::string name;
        std::cin >> name;

        int credits;
        std::cout << "Enter the credits for course " << i << ": ";
        std::cin >> credits;

        double grade;
        std::cout << "Enter the grade for course " << i << ": ";
        std::cin >> grade;

        courses.push_back({name, credits, grade});
    }

    // Calculate GPA
    double semesterGPA = calculateGPA(courses);
    std::cout << "GPA for the semester: " << semesterGPA << std::endl;

    // Calculate CGPA
    int numSemesters;
    std::cout << "Enter the number of semesters: ";
    std::cin >> numSemesters;

    double cumulativeGPA = semesterGPA * numSemesters;
    double cgpa = calculateCGPA(cumulativeGPA, numSemesters);
    std::cout << "CGPA: " << cgpa << std::endl;

    return 0;
}